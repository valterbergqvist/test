package com.example.demo.model;

public enum OrderStatus {
    PAID
}
